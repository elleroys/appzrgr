﻿using System;
using System.Threading.Tasks;

namespace AsynchronousMethodInvocationPattern
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("Starting main method.");

            await AsynchronousMethod();

            Console.WriteLine("main method completed.");
        }

        public static async Task AsynchronousMethod()
        {
            Console.WriteLine("Starting asynchronous method.");

            await Task.Delay(2000);

            Console.WriteLine("asynchronous method completed.");
        }
    }
}
