﻿using System;

namespace FacadePattern
{

    public class Subsystem1
    {
        public void Operation1()
        {
            Console.WriteLine("Subsystem1: Operation1");
        }
    }

    public class Subsystem2
    {
        public void Operation2()
        {
            Console.WriteLine("Subsystem2: Operation2");
        }
    }

    public class Facade
    {
        private readonly Subsystem1 _subsystem1;
        private readonly Subsystem2 _subsystem2;

        public Facade(Subsystem1 subsystem1, Subsystem2 subsystem2)
        {
            _subsystem1 = subsystem1;
            _subsystem2 = subsystem2;
        }

        public void Operation()
        {
            _subsystem1.Operation1();
            _subsystem2.Operation2();
        }
    }

    class Program
    {
        static void Main()
        {
            Subsystem1 subsystem1 = new Subsystem1();
            Subsystem2 subsystem2 = new Subsystem2();
            Facade facade = new Facade(subsystem1, subsystem2);
            facade.Operation();
        }
    }
}
