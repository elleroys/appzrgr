﻿using System;

namespace AbstractFactoryPattern
{
    public interface IAbstractFactory
    {
        IProductA CreateProductA();
        IProductB CreateProductB();
    }

    public class ConcreteFactory1 : IAbstractFactory
    {
        public IProductA CreateProductA()
        {
            return new ProductA1();
        }

        public IProductB CreateProductB()
        {
            return new ProductB1();
        }
    }

    public class ConcreteFactory2 : IAbstractFactory
    {
        public IProductA CreateProductA()
        {
            return new ProductA2();
        }

        public IProductB CreateProductB()
        {
            return new ProductB2();
        }
    }

    public interface IProductA
    {
        void DoSomething();
    }

    public class ProductA1 : IProductA
    {
        public void DoSomething()
        {
            Console.WriteLine("ProductA1 doing something.");
        }
    }

    public class ProductA2 : IProductA
    {
        public void DoSomething()
        {
            Console.WriteLine("ProductA2 doing something.");
        }
    }


    public interface IProductB
    {
        void DoSomething();
    }

    public class ProductB1 : IProductB
    {
        public void DoSomething()
        {
            Console.WriteLine("ProductB1 doing something.");
        }
    }

    public class ProductB2 : IProductB
    {
        public void DoSomething()
        {
            Console.WriteLine("ProductB2 doing something.");
        }
    }

    public class Client
    {
        private readonly IProductA _productA;
        private readonly IProductB _productB;

        public Client(IAbstractFactory factory)
        {
            _productA = factory.CreateProductA();
            _productB = factory.CreateProductB();
        }

        public void Run()
        {
            _productA.DoSomething();
            _productB.DoSomething();
        }
    }

    class Program
    {
        static void Main()
        {
            IAbstractFactory factory1 = new ConcreteFactory1();
            Client client1 = new Client(factory1);
            client1.Run();

            IAbstractFactory factory2 = new ConcreteFactory2();
            Client client2 = new Client(factory2);
            client2.Run();
        }
    }
}
